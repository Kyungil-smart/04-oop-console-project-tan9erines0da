﻿using System;
using System.Collections.Generic;
using System.Text;

public class Player
{
    public int y;
    public int x;

    public Player()
    { }
}
