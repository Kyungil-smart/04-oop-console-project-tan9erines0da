﻿
internal class Program
{
    static void Main(string[] args)
    {
        GameManager mainmanager = new GameManager();
        mainmanager.Run();
        
    }
}

